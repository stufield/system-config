
# Stu Field Documented Events

## Discussions with David

Below are notes from conversations with David Vegas, a Senior
member of the Cercle team. He expressed serious concerns
about the ability of Cercle to accommodate the shifting
directions, product requirements, model specifications,
and cultural environment in the lean resource state currently
faced by Cercle.

---

### Vikram

* David first expressed his concerns about Vikram, how he was
  siphoning resources from his (and our) team, via well-intentioned
  team members, particularly Santi and Dani.
  - we agreed to work together to remove the resource drain
    and force Vikram to work more independently. He knows this
    and now must work towards independent work.

### Text 2 Cypher

* The T2C product is a agent based tool used to transform
  natural language into Neo4j graph queries, execute the query
  and display the result in a hosted environment.
  - it is a prototype in its current stage of development
  - it is not even near the level of maturity required to
    expose to clients or any external entities
  - there are currently zero contexts to base the queries,
    and no truth standards to bas the results. There is no
    testing of output, and no way to evaluate the accuracy
    of the results
  - it is currently MONTHS away (or more) from an external product
  - there is no underlying DB for the system to learn, no
    security protocols, no logins, no storage of past prompts,
    and no way for the system to interact iteratively with the user
  - JC wants to expose this tool to Ferring, and David thinks
    this is a terrible idea


### Predictor Tool (P2P)

* the predictor tool (exposed tool to customers) predicts live birth
  success probabilities for 1-2-3 attempts for both IUI and IVF
  given a feature set of predictors: age, BMI, endometriosis, AMH, etc.


* extrapolation

* 60% AMH but all patients typically have AMH measured. Why only 60%.

* biasing the KNN neighborhood towards older patients to
  intentionally reduce the "over-optimistic" predictions from the
  original model during v2.1.
  - asked Andres to do this intentionally, call on 2025-09-23,
    he was concerned and disturbed








