
# Meeting Notes (sgf)
## Ferring Call of 2025-09-11; 6:00am

* Hien 
  - started off asking how we can help them
    clearly define their hypotheses.
  - open dialogue about what insights should
    be better undstood so it is clear
    what you're trying to achieve?

* Irene
  - concerned queries are inappropriate relative
    to the hypotheses they hope to benefit from the graph.
  - exclusion criteria may be *too strict* to isolate
    records/data that can answer their questions and
    could actually result in apples-to-pears comparisons
    different patient subpopulations. 
  - Need to ensure final comparison has comparable
    patient demographics
  - suggestion: look at patients Menupur (+/-)
    for pregnancy outcome (+/-)
  - not using all the data in the graph which is
    a mistake in her opinion

* Katie Barletta
  - learning that people tend to use Menopur "off-label"
  - so much variablitty in the data that swamps signal
  - variable isolation is the key, which is why they are
    concentrating hard on the queries, which they hope
    will simplify the demographics issues they wish
    to control for
  - struggling to understand/trust the data they
    receive from Cercle. MAJOR ISSUE!
  - missing data and spot checking gaps/errors and
    has resulted in lost confidence
  - they don't fully trust the data, and it's hard
    to accept a negative outcome when you don't have
    confidence in the data from which the outcome
    is generated
  - she also questions biological knowledge of engineers
    to make ad-hoc decisions during quiery/insight generation

* Wei Zhou
  - wants to ensure data can be used in high impact publication
  - must be highly rigorous curation process so that
    they can be 100% confident in the underlying data accuracy
  - inclusion/exclusion intended to control confounding variables
  - data standardization -> transformation across EMRs ->
    want to understand this process better and is a black
    box for him. How do we assure him we're doing this
    robustly?
  - how do we get them to an "analytical" data set?
    one with appropriately balanced subpopulations with
    comparable demographics?
  - he suggests:
    - to let them know what they can do to
      make Cercle process easier
    - we publish the White Paper on ingestion process
      ourselves, for them and for other potential customers
  - what would they need to see to have confidence in underlying
    data?
    - suggestion: a proper analysis with 80/20 train/test split
      looking at a *known* clinical outcome. Perhaps multiple.
      This would be a long-term project (weeks -> months)
      and might represent considerable resource allocation
      in Cercle's already lean/constrained FTE situation


