
## From: Rudy Eder

* severe reservations about Vikram's competence
* level of technical ability incredibly low;
  fails to believe possible he is contributing
  net positive to Cercle
* cycles through various asking for help
  - this is allegation
  - can't imagine executing on tasks independently
  - based on repeated roadblocks on same issue
* what happened:
  - credentials to SQL DB
  - incorrectly connect to MSSQL DB via POSTgres
  - asking how to do an ingestion for eIVF
  - tried to connect to `localhost`
* low level of technical ability and even reasoning ability
* attempted to download a S3 file, convert it to csv
  locally, then upload it to S3, which would invalidate
  the entire pipeline for future ingestions
* does not appear to be learning from mistakes

---

## Rudy's Words

* ran a script which failed and then he assumed the issue was with credentials
  to the MSSQL DB and/or their env vars
* enlisted the help of two devs
* asked questions about the required env vars that could be answered by looking
  at the code which was in front of him
* a screen share revealed that he runs the script and then ignores the detailed
  error messages that clearly state that the issue was Python library related

Overall:
  A clear lack of troubleshooting abilities or even desire.
  Just "run script and hope it works" and if not "ask for help".
