
# Meeting 2025-08-19

## IVY: Dallas

* Was told he would only have 1 week to complete
  the IVY: Dallas ingestion, but this was his first one
* With help from team was able to complete Dallas over
  the weekend (mostly) and complete the re-ingest
  on Monday
* L5 is still an open issue for PGT causing zeros in the Retool dashboard
  - Vikram he thinks the issue isn't
    with the ingestion but rather on
    the client side, and will need their
    input to resolve

## IVY: Sacramento

* Is now currently moved to IVY: Sacramento which
  is due in 2 weeks (JC has given a 1 week deadline)
  due to the progress miscommunication with Dallas
  - preliminary deadline is Friday Aug. 22nd, 2025
  - he views this as a "soft" deadline and is worried
    he won't be able to make it
  - there is a blocking issue (see below) stopping
    progress, but he is getting assistance from Diego
    and Santi
  - very difficult for him to estimate timelines due
    to lack of experience and confidence. 
  - very long iteration cycles also make accurate
    timelines estimates problematic

## XML Issue

* For the Sac ingestion there is a broken XML
  file during ingestion that is blocking progress

## Miscommunication

* claims didn't know Sac was due on Friday (08-15)
* but *owns* that he should have communicated 
  better, and told people that he was behind.
  Also clearing up that Sac wasn't started
  yet, only Dallas. He should have communicated
  better
* The Dallas ingestion is his first solo ingestion
* iteration cycles for:
  ingestion -> bug -> file isolation -> fix -> re-ingestion
  is WAY too long, even with partial ingestion

## Overall

* seems to know the tools well enough, has clearly
  learned the tool kit
* struggles with the biology, and intuitively locating
  where the issue comes from
* this is institutional knowledge, can be learned
  but is a major road block
* he is trying, but self-admittedly is slow


---


# Meeting 2025-09-04

*High level*: fairly frustrating call

* went through the ingestion process this week MANY times
  and each ingest-cycle takes ~1h to complete and debug.
  This is WAY too long

## Tool Walk through

Had Vikram walk me through the mapper tool via `make ingestion_tool`.
It hung on the initial steps so was difficult to assess. Likely
a missing credential on my end.

## IVY: Dallas

* still needs more internal refinement before complete
  - Santi provided feedback about KPIs that looked
    "off" but these are tribal knowledge heuristics
    and difficult to codify
  - meeting with customer lead tomorrow with all stakeholders
    to go over external validation
* based on feedback from customer, there may be additional
  external validation work to complete

## IVY: Sacramento

* there was only data up to 2014 in the SQL
  data bases, not much information
* that data has been imported
* eIVF-EMR Excel spreadsheets were remaining (2)
  and he used Santi's new AI ingestion tool for first time
  - feedback: tool works great(!) on *uningested* (i.e. unmapped
    by human) EMRs
  - for semi-complete ingestion it's actually easier to start from scratch
    since the tool tried to over-write existing (human) mappings.
  - Feature request to make semi-ingestions possible.
* L6 is still not populating on the ingestion
  - there appears to be a "frozen" `Cryo_Ref` file (no pun intended)
    that is breaking the process
  - he plans to ask Diego for help tomorrow and predicts
    this will populate the remaining dashboards and complete
    the Sacramento ingestion (minus future validation cycles
    or if additional data is provided by the customer)

## Assigned Tasks

* Develop (from existing materials) a `Troubleshooting guide`
  for future developers and engineers. Documentation for
  common gotchas that he has come across

* Develop a `Glossary of Terms` for commonly used terms
  at Cercle along with their definitions, mathematical
  representations, and extra information about fertility implications
  (why it's important to us)

* I have created a "Documentation" repository
  [here](https://gitlab.cercle.ai/data-science-team/documentation)


---

# Meeting 2025-09-19

* working on validation of IVY:Dallas
* has run into some inconsistencies in the ingestion tool
  reconciling the values from Amy to what the graph is ingesting
  - there are missing cycles and values for gestational sacs
  - can't figure out why this is happening, even though all
    files have been ingested
  - he is doing a reasonably good job at root causing the issue
  - unsuccessful so far but his thought process is sound
  - will talk with Dani for some insight into what he may be missing
  - he will report back to me in a few hours on progress
* he was previously not keeping the issue tracker Aleena set
  up to date; he is now making an effort to keep the "status"
  column accurate so that it properly reflects the current state
* overall I believe he's trying very hard, progress is slow
  but it's not completely his fault
  - this system is a mess, it's overly complex with very little
    root cause identifiers, almost zero documentation, and
    truth standards for the incoming data are nebulous
  - this is a serious problem, but it's not all Vikram
* Rudy's comments this week about his termination were
  completely uncalled for and unprofessional


