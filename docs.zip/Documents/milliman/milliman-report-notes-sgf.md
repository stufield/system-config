---
title: "Review of Milliman Report"
author: "Stu Field: Cercle Data Science Team"
date: "September 11 2025"
mainfont: "Times"
sansfont: "Times"
monofont: "Times"
fontsize: 12pt
toc: false
toc-depth: 3
links-as-notes: false
geometry: margin=1in
colorlinks: true
linkcolor: blue
urlcolor: blue
---


## Overall

* generally a fair and unbiased evaluation of the P2P tool and our software
  engineering process

* concludes that P2P tends to over-predict IVF success consistently across
  prediction cohorts (compared to actual data)

* work with Cercle to develop a decision cutoff that reflects
  the dynamic relative costs of false-positive and -negative results
  in a practical setting. Practically, where are biases acceptable?
  However, this report concentrates solely on a `cutoff = 0.5` as a
  benchmark for all performance metrics. Would the conclusions
  differ if they optimized via, say,
  [Youden's Index](https://en.wikipedia.org/wiki/Youden%27s_J_statistic)?

* they go into detail in some areas and explain quite clearly and logically,
  however in some areas comparisons are lacking detail. See below.

* possibly useful suggestion to use Principal Component Analysis (PCA)
  to facilitate dimensionality reduction, avoid fitting 'noisy' features,
  and/or reduce the dimensionality paradox
  ([aka curse of dimensionality](https://en.wikipedia.org/wiki/Curse_of_dimensionality)).


---


## Performance

* I am surprised about the overall Accuracy of the KNN model (0.637). For
  a binary classifier this not far from 0.50 (a 50/50 coin flip).
  Did our internal validation during model development
  catch this? Further, that a simple Logistic Regression model was able
  to outperform our highly developed KNN model very surprising.

* while I agree that Fig. 3A strongly indicates a pattern of over-prediction
  using the KNN model, this figure would be more convincing if provided
  with some sort of error estimation, either CI95% or SE bars.

* the performance metrics in Fig. 2 (yes there are 2 Fig. 2s)
  would be more convincing with CI95% to support the conclusions along
  with performance metrics from the Logistic Regression model they
  fit with 2023 data.

* I am surprised they didn't compare the P2P model predictions to actual
  predictions using a [Brier Score](https://en.wikipedia.org/wiki/Brier_score).
  This is an industry standard for comparing binary predictions which allows
  you to account for **how far** a model prediction is from the 0/1 prediction,
  not merely rely on the discretized binary class outcome for performance.
  It can also then be used to *better* compare two models, not merely
  comparing (CI95%-less) standard performance sens/spec/etc.

* I agree with their conclusion about Recall (also Sensitivity) bias
  and the 0.767 value compared to 0.568 Specificity. Careful consideration
  of pros/cons of false-positive and -negative can be optimized here
  regardless of the overall low accuracy (0.637)


## ROC Comparison

* only 1 ROC is provided (Fig. 2), for the Cercle KNN model. However the comparison
  model (Logistic Regression) is not plotted. This would provide
  a baseline comparison for *all* decision thresholds for both models.
  Including confidence intervals (CI95) for the decision threshold used
  (0.5) is also essential to determine *actual* overlap in performance.

* they mention further optimization of the decision threshold (from 0.5)
  as a future research endeavors, which seems pertinent considering
  the bias and potential clinical trade-off between false-positive 
  and false-negative. See Youden comment above.


## Curse of Dimensionality

* this is a well-known, significant issue with many distance-based
  modeling techniques
  [aka curse of dimensionality](https://en.wikipedia.org/wiki/Curse_of_dimensionality).

* considering there are indications that the KNN model can fail to find
  "near" enough neighbors (n = 100 -> n = 30 supports this),
  neighborhood selection seems critical.
  We may wish to investigate this deeper, and implement feature reduction
  techniques (there are many!) that might help with this issue.


