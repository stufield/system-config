
# Stu Field Documented Events

## Ferring Data Delivery

* 2025-09-12
* Significant data delivery for Query 1b scheduled to be 
  delivered to the Ferring group
  - the results were unfavorable to Ferring's product Menopur
  - the week before, it was discovered (Cristian) that the
    Boston IVF data, which was already ingested, was being
    excluded from the Query
  - after significant effort, the BIVF data was included
    not resulting in any qualitative change in Menopur outcome,
    despite the fact that BIVF had a bias in "no Menopur"
    cases to better balance out the groups
* a few days later, it was Diego was asked to review Pregnancy
  Loss and Fetus Live birth, and it was determined that losses
  were not being counted (or being double-counted?), either way
  this resulted in the `sum = babies + losses == pregnancies`
  calculation being incorrect
  - Cristian worked overnight to fix the issue
  - Hien and I met with Irene
* Cercle team met had met with Ferring to discuss issues
  in general where it was expressed (multiple times) that
  they had little confidence in the data they were seeing
  (until now).
* Now Friday morning (9/12) we (JC, Hien, Cristian, Stu)
  discussed 2 separate versions of the data, one including
  adjuvants and one excluding (yet another wrinkle in the
  confidence in the Query). Both versions showed a similar
  conclusion however
* Later that afternoon (Friday) during out 1:1 I expressed
  my concerns about the accuracy of the data, making last
  minute changes to sources and calculations, especially
  considering Ferring was already questioning data accuracy.
  - I asked him if he was comfortable with delivering
    the data as it stands, he said yes
  - also stated that no matter what Ferring will question
    the data, because the outcome for Menopur is bad for them
  - I stated that regardless of the outcome, all we can
    control is the our side of the data delivery, regardless
    of the conclusions.
* As a side note, I asked Hien her comfort level about the 
  data and all the last minute changes, and she was similarly
  concerned
* That evening JC asked Hien to send the data to Ferring
  without further confirmation or review, sending out
  a Slack message saying: 
  "after years of improving the graph, there is significantly higher
  probability that is accurate than not".
* I don't know if this was the correct decision, but my opinion
  is that we should at least convince ourselves of the data
  accuracy before sending anything out the door. Considering
  the significant changes over the past week, I do not know
  how we are able to do that


## Resource Allocation: Ferring 

* 2025-09-15

* my first week at Cercle a candidate, Kevin Lan, was presented
  as a possible new hire for my team. 
  - as I was new, I didn't know what my needs were at the time,
    but I trusted the team's opinion and their assessment of Kevin.
  - JC himself mentioned that if he were me he would hire Kevin
* I hired Kevin and we discussed, when ready, to on board him
  for the Ferring project
  - since the ferring project was expected to be relatively stable
    for the time being, it would be a good opportunity for Kevin
    to get his feet wet and gain experience
  - I mentioned this multiple times to JC, and he confirmed multiple times
* On Monday (9/15) Hien asked in a group Slack chat if it was time
  to add Kevin to the Ferring calls, to introduce him to the Team,
  and to start getting him some background since it was now 2 weeks
  in for Kevin. I had been prepping Kevin for the role, Dani had been
  training him for the role, Hien was notified and we were all prepared.
* Without discussing the me, JC responded to the group:
  | JC: Kevin needs to work on other things, Stu will take over Ferring
  |     as it was the plan from day 0 (edited) 
  |     so no, Kevin is not joining Ferring calls
  | Hien: Oh, okay, I didn't know that.
* This was a surprise to me too, as it was not discussed, in fact it
  was the opposite of what was discussed from day 0
* Context: in our 1:1 the week before JC clearly indicated to me that
  he thought I should be working in a more IC role, and diving into
  the scripts for Queries/extraction was critical in his opinion
* Are these issues related? I have no idea but a more professional
  way to handle things would be to take things offline and align
  with each other first, then respond publicly. Kevin is on my team,
  and therefore I should be deciding how to allocate his time/resource
  (in alignment with JC of course).


## Milliman Report

* 2025-09-11

* Milliman consulting was asked to generate a report on Cercle's modeling
  and internal process by a client (USF)
* Milliman kindly sent us a draft report prior to sending to USF asking
  for feedback and clarification
* JC sent out an email asking for comments on an email he had drafted
  in response to the report
* after obtaining some context and a copy of the report from Ashley,
  I dug into the report
  - I found the report critical but fair, non-biased, and considering
    their role in the situation, entirely above board. 
  - they had some concerns about model performance of the P2P product
  - the analysis was unbiased and raised logical questions
  - nothing out of the ordinary
* I wrote a response to the report myself, giving my honest feedback
  and concerns about their analysis.
  - issues I would have liked to see instead of that they presented
  - potential alternatives
  - I shared this 2 page response with JC privately as I didn't want
    to contradict anything he was saying publicly
* I then read JC's email in response to the report:
  - I found it disjointed and defensive
  - there were some legitimate details, but it came across
    as accusatory
  - at the same time, extensive use of technical jargon failed
    to sufficiently address the legitimate issues raised by the 
    Milliman report.
* I discussed this with JC, and he effectively said "don't worry about it"
  and that they would always have to find something wrong with Cercle
  so their client felt they got what they paid for.
  - so this was not an actual attempt to respond to the criticisms
    of the report itself
* To my surprise, JC had already sent his email to Milliman without
  waiting for the input he had asked for earlier in the day, and
  simply dismissed my report response out of hand.




## Ferring Meeting

* 2025-09-16
* we had a relatively mediocre meeting with the Ferring group,
  a little frustrating because they seem to be going in circles,
  but the relationship is what it is and they're paying us
* after the meeting the 4 of us, JC, Hien, Cristian and myself
  met separately
  - JC proceeded to lambaste the Ferring group as incompetent
    fools, without the expertise or base knowledge to succeed
    in this endeavour
  - repeatedly insulting them and their intelligence and ability
  - we were going in circles of insults, when I questioned
    "why don't we just give them what they want?"
  - I actually felt they were quite competent and were asking
    exactly the same questions I'd be asking if I were in their shoes
  - JC was fixated on the fact that they were simply dissatisfied
    with the outcome about Menopur, criticising their skills
    and, questioning why they want certain exclusion criteria enforced
  - fixated on the outcome is a distraction, we cannot control that
    and our only responsibility in this relationship is the quality
    of the underlying data we deliver. Nothing more.
  - I mentioned this but was dismissed (however in later Slack messages
    JC seemed to agree with my sentiment).
* The meeting was running long and I had a 1:1 I was later so I said
  that I had to go:
  - JC responded "no you stay right here! I am in charge of this group
    and I say what happens. And I say you take over the Ferring
    project from Cristian. Kevin will start with ingestion."
  - this context was in our previous conversation (Ferring: Resource Allocation)
    where JC told me I was to do Ferring, without discussion,
    even though Kevin had been working towards this allocation
    of resources since his hire date
  - I listened, did not commit to anything, and repeated that
    I had to jump to another call, then left the meeting.
  - I do not know what was said after I left


## Hiring Rant Over Slack

* 2025-09-16
* JC went into a multi-threaded group chat rant on Slack about
  out desperate need for hiring to assist in our lean resources,
  particularly on the ingestion side
  - the group included 5 high-level senior members at Cercle
  - it was mostly a stream of consciousness rant
  - very little actionable information beyond his belief 
    that we needed to hire contractors to stop-gap our resource
    limitations "or else we are going to die!"
  - this was multi-entry, repeated length chains of thoughts
    without much common thread, at times self-contradictory,
    both within the thread and what he's said elsewhere
  - I thought this exercise was pointless so did not engage
    in the conversation
  


## Next...






---

**Charlatan**
: is a fraud who deceives others by pretending to have more knowledge, skill,
  or expertise than they actually possess, often for personal gain such as money
  or fame. Essentially, a charlatan is a fake, a impostor, or a quack who uses
  tricks, elaborate schemes, or skilled persuasion to promote their false claims.
  The term often refers to someone in medicine who sells ineffective remedies but
  can also apply to people in other fields who falsely present themselves as authorities. 





