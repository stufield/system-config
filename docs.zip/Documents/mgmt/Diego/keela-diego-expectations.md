
# Subject

Excerpt from a e-mail conversation between Keela Fett and
Diego Urbina in July 2025 regarding expectations moving
forward for his employment with Cercle.


---------- Forwarded message ---------
From: Diego Urbina <diego.urbina@cercle.ai>
Date: Tue, Jul 29, 2025 at 12:07 PM
Subject: Re: Cercle Working Expectations
To: Keela Fett <keela@cercle.ai>


Keela,

Thank you very much.

This is a good guideline. I agree with it and consider it valuable.

Will keep it in mind for improvements regarding team work.

Whenever I have questions will come back to this email.


Thanks again,
Diego Urbina

Engineering
diego.urbina@cercle.ai

Advancing Healthcare for All Women
www.cercle.ai


---


On Tue, 29 Jul 2025 at 18:05 Keela Fett <keela@cercle.ai> wrote:
Hey Diego,

I wanted to bump this up to make sure you saw and understand this. Will you
confirm if this all makes sense and if you have any questions? Thank you! 

 On Fri, Jul 25, 2025 at 10:42 AM Keela Fett <keela@cercle.ai> wrote:
 Hey Diego,

 Thank you so much for your time this morning. As promised, see below the items
 we covered today. If you have any questions at all, please let me know. Own
 Your Media & JC are aware of this as well, so you can feel free to talk with
 either of them for feedback on whether you are meeting expectations. 
 
 * We are raising your salary $1000 USD monthly starting July 2025. 
 * In exchange, we expect to see performance improvements in the following areas:
   - Working hours:
     - Be clearer on what time zone you’re in and what hours your team can
       expect you online
      - You are generally expected to work 40 hours per week, with ~4+ hours of
        overlap with Spain team per day
   - Need to be more responsive on slack - there are instances where 12 hours
     go by without a response, and that makes collaboration on a remote team
     very difficult
     - In general, engineers typically respond within 1 hour when it is the
       workday (i.e. not the middle of the night)
   - More proactive communications on where you are with your deliverables.
     - Take more ownership of your tasks and communicate progress early and often.
   - Documentation:
     - Work with Stu & JC on a better process to document your knowledge so we
       remove single points of failure.

Stu is starting full-time on August 11th, but I will connect you with him
sooner. We expect that you will be helping him onboard, and you can expect him
to give you regular feedback and coaching so you can continue to grow
professionally. 


---------------------
Keela Fett (she/her) 
Operations Manager
cercle.ai | Advancing healthcare for all women

