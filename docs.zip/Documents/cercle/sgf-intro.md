
# Stu Field Intro to Team

* Canadian

* Living FoCo

* PhD Germany; Host-parasite

* Postdoc; disease dynamics modeling

* 15 years Life Sciences
  - proteomics
  - predictive disease modeling
  - CVD, Alz, NASH

