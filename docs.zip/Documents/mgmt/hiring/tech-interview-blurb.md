

Thank you for agreeing to meet with a member of our
data engineering team. You will be meeting with Santi, XX POSITION,
who will be covering SQL, Neo4j, DB queries, data pipelining,
clinical data management, and AI integration.
We are excited about your candidacy and hope to see/hear from you soon.
