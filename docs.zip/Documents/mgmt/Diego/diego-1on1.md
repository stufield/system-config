
# Meeting 2025-08-29

* high level discussion about performance concerns, particularly
  related to responsiveness during cross-functional team interactions
* he recognized that his communication is poor and accepts
  responsibility for those failures.
* I provided him with best practices moving forward that he
  could employ to facilitate communication, like:
  - updating `Slack` status
  - use of sync tools like `Clockwise` and `Google Calendar` apps in Slack
  - err on the side of "over-communication"
  - add focus time to Calendar
  - be open, honest, and up front about deadlines that may slip
  - push back immediately if a deadline is too short
* this was partly an entablement failure on management part to enable
  Diego to push back on unrealistic timelines
  - he now feels he can push back (at least should)
  - but he must also be honest when deadlines at risk
* moving forward Diego promises to work to improve responsiveness
  and mature his communication style with members of GTM:
  - particularly with interactions with Aleena and David, who are frustrated
    and feel disrespected
  - they need to know what is happening to effectively communicate timelines to
    customers

---

# Meeting 2025-09-05

## Communication

* I have noticed significant improvement over the past week with
  better communication and updates. Not perfect but an improvement
* he has installed and is using the Clockwise App in Slack to
  facilitate status updates to team members
* sometimes has difficulty accurately estimating timelines for tasks
  - this may results in missed deadlines
  - he's often over-optimistic with estimates
    then doesn't feel he can back out of that promise
  - I've told him to buffer his estimates by 1/2 a day to 
    ensure he has enough time, and only promise items
    when he's sure he can accomplish the action item in the allotted time

## IVY: Virginia

* dashboard is on ok position. Mostly complete and passing most
  heuristic sanity checks.
* one outlying issue is C4 (Gestational Carrier) which he estimates
  will take one day to complete (9/5)
* the additional (C5) issue, which appears to the customer as an
  error in the dashboard as C5, is actually another separate issue
  with C4. This will take a half day to complete and will 
  begin this Monday (9/8)

## IVY: PNWF

* Issue C2: Doctor full names -> needs to be updated and re-ingested
  - this is a simple task, less than half a day (will complete Monday 9/8)
* see propagation issues below which represents work to be
  completed here as well

## Issues

* Propagation: When an issue arises in one data source, that same issue must also be
  resolved in other partner clinic data sources. This represents a sunken
  time cost to his workflow and timelines. Managing Virginia/PNWF sync
  is non-trivial. I do not know (or worry) about how this sync is
  being handled with other partner clinics (Sacramento & Dallas).
* Re-ingestion cycle: when a fix is applied, e.g. C4, a re-ingestion
  must be triggered to update all the downstream machinery. This re-ingestion
  takes > 1h, meaning that the debug cycle is delayed, and cannot
  move on to other issues. This represents a major pain point
  in the pipeline which must be addressed.


# Meeting 2025-09-19

* Diego now working full-time on the Genea ingestion
  - he has > 150 parquet files to ingest and is donig so manually
  - JC said he must use Santi's AI ingestion tool to cut that by 70%
  - however, JC has a basic misunderstanding of the tool implementation
  - not a simple push of a button
  - he is working hard and making progress, albeit slower than hoped
  - however, those expectations may have been misguided to begin with
* I asked him to created an informal short-term milestones for how
  he sees the Genea project
  - this way we have a planned road map of progress with measureable
    goals/milestones
  - he has done so and it looks good to me



