
| Customer       | Data Source   | EMR      | Analyst        |
| -------------  | ------------- | -------- | -------------- |
| BostonIVF (ex) | `NA`          | `NA`     | `NA`           |
| US Fertility   | Ovation       | Artisan  | Andres         |
|                | FCI           | Fert     | Dani           |
|                | IVF           | Fert     | Dani           |
|                | BAY           | Fert     | Dani           |
|                | SGF           | Fert     | Dani           |
|                | RMANY         | ?        | Santi          |
|                | Rader Soln    | eIVF     | Diego (?)      |
| IVY            | PNW           |          | Diego          |
|                | Virginia      |          | Diego          |
|                | Dallas        |          | Vikram         |
|                | Sacramento    | eIVF     | Vikram         |
| Genea          | BabySentry    |          | Diego          |
|                | Genie         |          |                |
|                | Genie-Spec    |          |                |
|                | Geri Incu     |          |                |
| Ferring        | `NA`          | ?        | Cristian/Kevin |
| EMD-Merck      | `NA`          | ?        | ?              |


