
# 2025-08-13

* Ferring

  - going well, under control
  - concern is that if multiple client requests
    occur simultaneously could be road block
  - he is single owner silo of information,
    needs backup

* Kevin Lan

  - Dani is willing to meet Kevin to assess fit
  - tech (Python) and cypher query background (?)
  - clinical background (+)
  - onboarding time 2-3mo minimum

* Andres?

  - Dani relies heavily on ingestion
  - which team is he part of?
  - does it make sense for him to work closer with the team/Dani?


* Data Access Tool (DAT)

  - internal QC of ingestion
  - external exposed


* Tech Debt for DAT

  - Dani wants to refactor/improve/simplify the code
  - implementation will facilitate new onboarding,
    speed up quieries, and simplify future upgrades

---

# 2025-09-04

* Working on QA dashboard for USF
  - Ovation (Artisan): Andres + 1 external person validating the dashboards
  - RMANY (???): Santi + 1 external person validating the dashboards
  - SGF, FCI, IVF, and BAY (Fert): Dani + 4 external people validating the dashboards
    - 1 per organization: SGF (Christina), FCI, IVF, and BAY

* QA Dashboard Validation
  - working on feedback from Christina for USF-SGF
  - going well but needs time to clean up
  - multiple ingestion (almost daily)

* Unplanned Work
  - currently mid-level task switching costs and unplanned work
  - unplanned work resulting from team support
  - as a senior member (and capable) this will be the case
  - but long-term goal is to minimize this

* Wants to work with Cristian to close the loop on 
  taking over Ferring from him, or, perhaps eventually
  handing off to Kevin

* Onboarding of Kevin
  - currently daily 1:1 with Kevin
  - at this point merely setup and tools, access and credentials, etc.


