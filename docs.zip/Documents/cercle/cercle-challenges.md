
# Challenges Facing Cercle

## Processes Unscaleable
 
* Many current processes not scaleable as the company 
  grows to add more fertility clinics
* further, growth beyond fertility will be impossible
  if the scalability issues are not addressed
  - too much local knowledge isolated in certain individuals
  - sparse documentation traps knowledge in silos
  - hiring: multiple hiring simultaneously will 
    require supporting Keela with more HR related capacity

### Long Ingestion Cycle

* data ingestion is currently a road block in Cercle's
  data pipeline
  - a single ingestion cycle takes up to 2h, making the
    debug cycle painfully slow to iterate


## Lacking Truth Standards

* difficult to know when an ingestion (or extraction) is accurate
  - very few internal checks, sanity checks, or heuristic
    checks to ensure accuracy
  - ingestion "validation" is a series of approximations
    that relies on tribal knowledge and experience of the analyst
  - this is followed by external "validation" by the client
    whereby they merely spot check a small portion of
    the ingested data


## Lack of Documentation

### External

* this is very little technical documentation regarding
  the data pipeline, ingestion, validation and query
  processes at Cercle
  - this makes it difficult to develop trust about
    data governance and accuracy

### Internal

* the lack of documentation *internally* makes it difficult
  to efficiently train and onboard new hires
* no documentation -> no on-boarding -> no scaling the company 
* documentation and process control is key to future growth


## Culture

### Slack

* the use of Slack as a universal stream of consciousness
  is inefficient and distracting.
  - while it may have sufficed historically, a larger
    organization would suffer extensive lack of production
    if Slack continues to be used in such a fashion

### Chaotic Workflows

* common fire drills inhibit productivity via task switching
  and are tough on morale
  - while the startup environment such situations are
    at times unavoidable, it should not be the norm
  - careful and consistent attention to process and
    organized workflows must be implemented, otherwise
    the organization will most likely experience:
    - significant employee churn
    - impediment to growth/scalability
    - data accuracy/confidence issues



