
data <- readxl::read_xlsx("attrition_tables.xlsx", sheet = 1, skip = 1)
data2 <- readxl::read_xlsx("attrition_tables.xlsx", sheet = 2, skip = 1)
#write.csv(data[, 1:3], row.names = FALSE, file = "attrition-table1.csv")
#write.csv(data2[, 1:3], row.names = F, file = "attrition-table2.csv")
data

df_int <- read.csv("attrition-table1.csv") |>
  tibble::as_tibble()

df_comp <- read.csv("attrition-table2.csv") |>
  tibble::as_tibble()


attrition_burndown <- function(data, var, label, add_label = TRUE) {

  data$query_index <- seq_len(nrow(data))

  label_df <- tibble::tibble(
    label = tail(data[[label]], -1L),
    y     = head(data[[var]], -1L),
    x     = tail(data$query_index, -1L) 
  )

  p <- data |>
    ggplot(aes(x = query_index, y = !!str2lang(var))) +
    geom_step(direction = "hv", colour = "#00A499", linewidth = 0.5,
              linetype = "solid") +
    geom_point(data = label_df, aes(x = x, y = y), color = "black", 
               alpha = 0.5, size = 1) +
    labs(title = "Attrition Burndown",
         y = "Retrievals (n)",
         x = "Query Filter") +
    scale_x_continuous(expand = expansion(mult = c(0.05, 0.10))) +
    theme(
      axis.text.y = element_text(angle = 45, hjust = 1),
      plot.title  = element_text(hjust = 0.5)
    )

  if (add_label) {
    p <- p + geom_text(data = label_df, aes(x = x, y = y, label = label),
                       size = 2, angle = 45, hjust = -0.025, check_overlap = TRUE) +
    coord_cartesian(clip = "off")
  }

  p
}

attrition_burndown(df_int, "Oocyte_Retrievals", "Criteria")


attrition_burndown2 <- function(data = list(...), var, label) {

  if (is.null(names(data))) {
    # named list makes the group names via the list
    names(data) <- sapply(substitute(data)[-1L], base::deparse)
  }

  data <- lapply(data, function(.x) {
    .x$query_index <- seq_len(nrow(.x))
    .x}) |> dplyr::bind_rows(.id = "group")

  data |>
    ggplot(aes(x = query_index, y = !!str2lang(var), color = group)) +
    geom_step(direction = "hv", linewidth = 0.5, linetype = "solid") +
    geom_point(data = dplyr::filter(data, query_index < max(query_index)),
               aes(x = query_index + 1, y = !!str2lang(var)),
               color = "black", alpha = 0.5, size = 1) +
    labs(title = "Attrition Burndown",
         y = "Retrievals (n)",
         x = "Query Filter") +
    scale_x_continuous(expand = expansion(mult = c(0.05, 0.10))) +
    theme(
      axis.text.y = element_text(angle = 45, hjust = 1),
      plot.title  = element_text(hjust = 0.5)
    )
}

attrition_burndown2(
  list(Intervention = df_int, Comparison = df_comp),
 "Oocyte_Retrievals", "Criteria"
)
