
## Questions

* Have you ever worked in a setting where the product was still evolving?
  How did you adapt to frequent updates or changes?

* Database troubleshooting; describe a time where you saw unexpected results
  from a query, seemed off, how did you diagnose and address the issue?

* Share an example of a time you achieved significant results early in
  your role despite the lack of a clear roadmap.
  What strategies did you use?

* How do you handle working across time zones or diverse teams, and
  how do you prefer to collaborate with others?

* What excites you about working in a small company or startup environment?

* Do you have any public examples of your coding? GitHub repos?


## Conclusion

* Overall did great on all inqueries
* Understands the uncertainty and chaotic nature of clinical data
* Enjoys incremental improvement -> building the airplane as you're flying it
* Experienced direct contact with clients
  - can communicate fluently with them
* Knows the relational DB SQL framework, should be simple to 
    apply to Neo4j and cypher queries
* Can begin right away

## Kevin Lan

* Kevin has accepted offer to join Data Science Team
* brings strong biology background as pharmacist
* background should position him to contribute
  clients in pharma space. 
  - also well positioned as we move beyond fertility
* experience in database mgmt and pipeline execution
  that we can build upon: clinical ingestion and query extraction
* importantly I belive he has an engine
